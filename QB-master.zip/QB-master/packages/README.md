QuickBox Application Installer and Removal Packages
