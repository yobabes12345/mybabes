
</body>
</html>
<?php session_destroy(); ?>
