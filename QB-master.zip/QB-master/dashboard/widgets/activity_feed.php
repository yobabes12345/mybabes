<?php
  //QuickBox Development & Activity Feed
?>
<embed src="https://quickbox.io/widget/feed/qb-project_dark.php" width='100%' height='100%' style="padding-bottom: 45px;" />
