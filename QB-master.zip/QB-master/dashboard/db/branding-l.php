<a href="#"><img src="img/logo-light.png" alt="QuickBox Seedbox" class="logo-image" height="50" /></a>
