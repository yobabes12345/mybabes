<ul class="dropdown-menu pull-right">
  <li style="border-top: 1px solid #444"><a href="https://plaza.quickbox.io/c/quickbox-support" target="_blank"><i class="fa fa-warning text-warning"></i><?php echo T('ISSUE_REPORT_TXT'); ?></a></li>
</ul>
