﻿/*
 * PLUGIN CHECK_PORT
 *
 * Serbian language file.
 *
 * Author: 
 */

 theUILang.checkPort		= "Check Port Status";
 theUILang.portStatus		= [
 				  "Port status is unknown",
 				  "Port is closed",
 				  "Port is open"
 				  ];

thePlugins.get("check_port").langLoaded();