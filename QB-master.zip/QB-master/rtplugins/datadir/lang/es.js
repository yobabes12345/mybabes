﻿/*
 * PLUGIN DATADIR
 *
 * Spanish language file.
 *
 * Author: 
 */

 theUILang.DataDir		= "Guardar en";
 theUILang.DataDirMove		= "Mover datos";
 theUILang.datadirDlgCaption	= "Directorio de datos del Torrent";
 theUILang.datadirDirNotFound	= "DataDir plugin: Directorio inválido";
 theUILang.datadirSetDirFail	= "DataDir plugin: Operación fallida";

thePlugins.get("datadir").langLoaded();